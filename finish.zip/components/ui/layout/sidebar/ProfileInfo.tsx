"use client";

export default function ProfileInfo() {
  return <div className="w-6 h-6 rounded-full bg-amber-300"></div>;
}

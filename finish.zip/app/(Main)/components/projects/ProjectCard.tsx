import Image from "next/image";
import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { FaGithub } from "react-icons/fa";
import type { Project } from "./projects-data";

type ProjectCardProps = {
  project: Project;
};

export default function ProjectCard({ project }: ProjectCardProps) {
  const technologies = project.technologies ?? [];

  return (
    <article
      className="
        group overflow-hidden rounded-2xl
        border border-border bg-card
        transition-all duration-300
        hover:-translate-y-1
        hover:border-primary/50
        hover:shadow-xl hover:shadow-primary/10
      "
    >
      {/* تصویر پروژه */}
      <div className="relative aspect-16/10 overflow-hidden bg-muted">
        {project.image_url ? (
          <Image
            src={project.image_url}
            alt={project.title}
            unoptimized
            fill
            loading="lazy"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            className="
              object-cover transition-transform
              duration-500 group-hover:scale-105
            "
          />
        ) : (
          <div
            className="
              flex h-full w-full items-center
              justify-center text-sm
              text-muted-foreground
            "
          >
            تصویر پروژه موجود نیست
          </div>
        )}

        <div className="absolute inset-0 bg-linear-to-t from-black/40 to-transparent opacity-70" />
      </div>

      {/* اطلاعات پروژه */}
      <div className="flex flex-col gap-4 p-4 sm:p-5">
        <div className="flex items-start justify-between gap-3">
          <h2 className="text-lg font-bold text-foreground">{project.title}</h2>
        </div>

        <p className="min-h-12 text-sm leading-7 text-muted-foreground">
          {project.description ?? "توضیحی برای این پروژه ثبت نشده است."}
        </p>

        {/* تکنولوژی‌ها */}
        {technologies.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {technologies.map((technology) => (
              <span
                key={technology}
                className="
                  rounded-lg border border-border
                  bg-background px-2.5 py-1
                  text-xs font-medium
                  text-muted-foreground
                "
              >
                {technology}
              </span>
            ))}
          </div>
        )}

        {/* لینک‌ها */}
        <div className="flex items-center gap-3 border-t border-border pt-4">
          {project.demo_url && (
            <Link
              href={project.demo_url}
              target="_blank"
              rel="noopener noreferrer"
              className="
                inline-flex items-center gap-2
                rounded-xl bg-primary px-3 py-2
                text-sm font-medium text-white
                transition-opacity hover:opacity-90
              "
            >
              مشاهده پروژه
              <ExternalLink size={15} />
            </Link>
          )}

          {project.github_url && (
            <Link
              href={project.github_url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`کد منبع ${project.title}`}
              className="
                inline-flex size-10 items-center
                justify-center rounded-xl border
                border-border bg-icon-bg
                text-primary transition-colors
                hover:bg-muted
              "
            >
              <FaGithub size={20} />
            </Link>
          )}

          {!project.demo_url && !project.github_url && (
            <span className="text-xs text-muted-foreground">
              لینک پروژه هنوز تنظیم نشده
            </span>
          )}
        </div>
      </div>
    </article>
  );
}

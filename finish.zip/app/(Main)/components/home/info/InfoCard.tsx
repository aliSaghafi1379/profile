import type { ReactNode, ElementType } from "react";

type InfoCardProps = {
  icon: ElementType;
  title: string;
  children: ReactNode;
};

export default function InfoCard({
  icon: Icon,
  title,
  children,
}: InfoCardProps) {
  return (
    <div
      className={`flex items-center w-full gap-4 rounded-2xl border border-border bg-card p-4`}
    >
      <div className="flex size-14 shrink-0 items-center justify-center rounded-full bg-icon-bg text-primary">
        <Icon size={26} />
      </div>

      <div className="min-w-0">
        <h3 className="font-semibold text-foreground">{title}</h3>

        <div className="mt-2 text-sm leading-6 text-muted-foreground">
          {children}
        </div>
      </div>
    </div>
  );
}

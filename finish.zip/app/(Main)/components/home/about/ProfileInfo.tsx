type ProfileInfoProps = {
  fullName: string;
  jobTitle: string;
  bio: string;
};

export default function ProfileInfo({
  fullName,
  jobTitle,
  bio,
}: ProfileInfoProps) {
  return (
    <div className="w-full flex flex-col gap-4 items-center md:flex-1 md:inline">
      {/* نام و نام خانوادگی */}
      <p className="text-4xl font-bold leading-tight text-foreground sm:text-5xl md:text-6xl md:mb-3">
        {fullName}
      </p>

      {/* شغل */}
      <p className="text-xl font-semibold text-primary sm:text-2xl md:mb-4">
        {jobTitle}
      </p>

      {/* درباره من */}
      <p className="w-full text-base leading-8 text-sidebar-text text-justify tracking-tighter">
        {bio}
      </p>
    </div>
  );
}

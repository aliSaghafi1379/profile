import {
  SiNextdotjs,
  SiReact,
  SiTypescript,
  SiTailwindcss,
  SiShadcnui,
  SiGit,
  SiDocker,
} from "react-icons/si";

import { Code2 } from "lucide-react";
import type { IconType } from "react-icons";
import type { Skill } from "./skills-data";

const iconMap: Record<string, IconType> = {
  nextjs: SiNextdotjs,
  react: SiReact,
  typescript: SiTypescript,
  tailwind: SiTailwindcss,
  shadcn: SiShadcnui,
  git: SiGit,
  docker: SiDocker,
  vscode: Code2,
};

const iconColors: Record<string, string> = {
  nextjs: "#FFFFFF",
  react: "#61DAFB",
  typescript: "#3178C6",
  tailwind: "#06B6D4",
  shadcn: "#FFFFFF",
  git: "#F05032",
  docker: "#2496ED",
  vscode: "#007ACC",
};

type SkillCardProps = {
  skill: Skill;
};

export default function SkillCard({ skill }: SkillCardProps) {
  const Icon = iconMap[skill.icon];

  return (
    <article className="flex min-w-0 flex-col items-center rounded-2xl border border-border bg-card p-3 transition-colors duration-200 hover:border-primary/60 sm:p-4">
      <div className="mb-3 flex size-14 items-center justify-center rounded-2xl border border-border bg-icon-bg/50 sm:size-16">
        {Icon ? (
          <Icon
            size={34}
            color={iconColors[skill.icon] ?? "currentColor"}
            aria-hidden="true"
          />
        ) : (
          <span className="text-xs text-muted-foreground">
            {skill.name.slice(0, 2)}
          </span>
        )}
      </div>

      <h3 className="text-center text-sm font-semibold text-foreground sm:text-base whitespace-nowrap">
        {skill.name}
      </h3>

      <span className="mt-1 text-xs text-muted-foreground">
        {skill.level >= 70 && skill.level <= 100
          ? "پیشرفته"
          : skill.level >= 40 && skill.level < 70
            ? "متوسط"
            : "مبتدی"}
      </span>

      <div
        className="mt-3 h-2 w-full overflow-hidden rounded-full bg-muted"
        role="progressbar"
        aria-label={`میزان تسلط به ${skill.name}`}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={skill.level}
      >
        <div
          className="h-full rounded-full bg-primary transition-[width] duration-500"
          style={{
            width: `${Math.min(100, Math.max(0, skill.level))}%`,
          }}
        />
      </div>
    </article>
  );
}

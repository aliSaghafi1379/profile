export type Skill = {
  id: string;
  name: string;
  icon: string;
  level: number;
  sortOrder: number;
  isActive: boolean;
};

export type OtherSkill = {
  id: string;
  name: string;
  icon: string;
};

// export const skills: Skill[] = [
//   {
//     id: "1",
//     name: "Next.js",
//     icon: "nextjs",
//     level: 20,
//     sortOrder: 1,
//     isActive: true,
//   },
//   {
//     id: "2",
//     name: "React",
//     icon: "react",
//     level: 45,
//     sortOrder: 2,
//     isActive: true,
//   },
//   {
//     id: "3",
//     name: "TypeScript",
//     icon: "typescript",
//     level: 85,
//     sortOrder: 3,
//     isActive: true,
//   },
//   {
//     id: "4",
//     name: "Tailwind CSS",
//     icon: "tailwind",
//     level: 90,
//     sortOrder: 4,
//     isActive: true,
//   },
//   {
//     id: "5",
//     name: "shadcn/ui",
//     icon: "shadcn",
//     level: 80,
//     sortOrder: 5,
//     isActive: true,
//   },
//   {
//     id: "6",
//     name: "Git",
//     icon: "git",
//     level: 85,
//     sortOrder: 6,
//     isActive: true,
//   },
//   {
//     id: "7",
//     name: "Docker",
//     icon: "docker",
//     level: 55,
//     sortOrder: 7,
//     isActive: true,
//   },
//   {
//     id: "8",
//     name: "VS Code",
//     icon: "vscode",
//     level: 85,
//     sortOrder: 8,
//     isActive: true,
//   },
// ];

// export const otherSkills: OtherSkill[] = [
//   { id: "1", name: "Framer Motion", icon: "framer-motion" },
//   { id: "2", name: "Zustand", icon: "zustand" },
//   { id: "3", name: "Axios", icon: "axios" },
//   { id: "4", name: "React Query", icon: "react-query" },
//   { id: "5", name: "Postman", icon: "postman" },
//   { id: "6", name: "Figma", icon: "figma" },
//   { id: "7", name: "ESLint", icon: "eslint" },
// ];

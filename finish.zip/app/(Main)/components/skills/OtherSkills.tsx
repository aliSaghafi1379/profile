import type { OtherSkill } from "./skills-data";

type OtherSkillsProps = {
  skills: OtherSkill[];
};

export default function OtherSkills({ skills }: OtherSkillsProps) {
  return (
    <section className="mt-7 w-full">
      <h2 className="mb-4 text-base font-bold text-primary sm:text-lg">
        سایر ابزارها و کتابخانه‌ها
      </h2>

      <div className="flex flex-wrap gap-2">
        {skills.map((skill) => (
          <span
            key={skill.id}
            className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-2 text-xs text-foreground transition-colors hover:border-primary/60 sm:text-sm"
          >
            <span
              className="size-2 rounded-full bg-primary"
              aria-hidden="true"
            />
            {skill.name}
          </span>
        ))}
      </div>
    </section>
  );
}

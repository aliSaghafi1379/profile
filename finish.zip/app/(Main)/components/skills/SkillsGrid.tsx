import SkillCard from "./SkillCard";
import type { Skill } from "./skills-data";

type SkillsGridProps = {
  skills: Skill[];
};

export default function SkillsGrid({ skills }: SkillsGridProps) {
  const visibleSkills = skills
    .filter((skill) => skill.isActive)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className="grid grid-cols-3 gap-2.5 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 w-full">
      {visibleSkills.map((skill) => (
        <SkillCard key={skill.id} skill={skill} />
      ))}
    </div>
  );
}

import Link from "next/link";
import { SiTelegram, SiInstagram, SiWhatsapp } from "react-icons/si";
import { FiLinkedin, FiMail, FiPhoneCall, FiArrowUpLeft } from "react-icons/fi";
import type { IconType } from "react-icons";
import type { ContactItem } from "./contact-data";

const iconMap: Record<string, IconType> = {
  telegram: SiTelegram,
  linkedin: FiLinkedin,
  instagram: SiInstagram,
  whatsapp: SiWhatsapp,
  email: FiMail,
  phone: FiPhoneCall,
};

type ContactCardProps = {
  contact: ContactItem;
};

export default function ContactCard({ contact }: ContactCardProps) {
  const Icon = iconMap[contact.icon];

  return (
    <Link
      href={contact.href}
      target={contact.href.startsWith("https://") ? "_blank" : undefined}
      rel={
        contact.href.startsWith("https://") ? "noopener noreferrer" : undefined
      }
      className="group flex justify-start min-w-0 items-center gap-3 rounded-2xl border border-border bg-card p-4 transition-all duration-300 hover:-translate-y-1 hover:border-primary/60 sm:gap-4 sm:p-5"
    >
      <div
        className="flex size-12 shrink-0 items-center justify-center rounded-2xl border border-border bg-muted/50 sm:size-14"
        style={{ color: contact.color }}
      >
        {Icon ? (
          <Icon size={26} aria-hidden="true" />
        ) : (
          <span className="text-sm font-bold">
            {contact.title.slice(0, 1)}{" "}
          </span>
        )}{" "}
      </div>

      <div className="min-w-0 flex flex-col ">
        <h2 className="text-sm font-bold text-foreground sm:text-base">
          {contact.title}
        </h2>

        <p
          dir="auto"
          className="mt-1 wrap-break-words text-xs leading-6 text-muted-foreground sm:text-sm"
        >
          {contact.value}
        </p>
      </div>
      <FiArrowUpLeft
        size={18}
        aria-hidden="true"
        className="shrink-0 text-muted-foreground transition-colors group-hover:text-primary"
      />
    </Link>
  );
}

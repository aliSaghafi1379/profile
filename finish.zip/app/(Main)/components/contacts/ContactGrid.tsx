import ContactCard from "./ContactCard";
import type { ContactItem } from "./contact-data";

type ContactGridProps = {
  contacts: ContactItem[];
};

export default function ContactGrid({ contacts }: ContactGridProps) {
  const visibleContacts = contacts
    .filter((contact) => contact.isActive)
    .sort((a, b) => a.sortOrder - b.sortOrder);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-3 sm:grid-cols-2 sm:gap-4 w-full">
      {visibleContacts.map((contact) => (
        <ContactCard key={contact.id} contact={contact} />
      ))}{" "}
    </div>
  );
}

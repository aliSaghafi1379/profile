export type ContactItem = {
  id: string;
  title: string;
  value: string;
  href: string;
  icon: string;
  color: string;
  sortOrder: number;
  isActive: boolean;
};

// export const contactItems: ContactItem[] = [
//   {
//     id: "telegram",
//     title: "تلگرام",
//     value: "@Ali_Saghafi",
//     href: "https://t.me/Ali_Saghafi",
//     icon: "telegram",
//     color: "#229ED9",
//     sortOrder: 1,
//     isActive: true,
//   },
//   {
//     id: "linkedin",
//     title: "لینکدین",
//     value: "پروفایل لینکدین من",
//     href: "https://www.linkedin.com/in/your-username",
//     icon: "linkedin",
//     color: "#0A66C2",
//     sortOrder: 2,
//     isActive: true,
//   },
//   {
//     id: "instagram",
//     title: "اینستاگرام",
//     value: "@ali_saghafi",
//     href: "https://www.instagram.com/your-username/",
//     icon: "instagram",
//     color: "#E4405F",
//     sortOrder: 3,
//     isActive: true,
//   },
//   {
//     id: "whatsapp",
//     title: "واتس‌اپ",
//     value: "+98 912 345 6789",
//     href: "https://wa.me/989123456789",
//     icon: "whatsapp",
//     color: "#25D366",
//     sortOrder: 4,
//     isActive: true,
//   },
//   {
//     id: "email",
//     title: "ایمیل",
//     value: "ali@example.com",
//     href: "mailto:ali@example.com",
//     icon: "email",
//     color: "#8B5CF6",
//     sortOrder: 5,
//     isActive: true,
//   },
//   {
//     id: "phone",
//     title: "شماره تماس",
//     value: "+98 912 345 6789",
//     href: "tel:+989123456789",
//     icon: "phone",
//     color: "#06B6D4",
//     sortOrder: 6,
//     isActive: true,
//   },
// ];

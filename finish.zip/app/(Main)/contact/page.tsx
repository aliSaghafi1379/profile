import ContactGrid from "../components/contacts/ContactGrid";
import TitleForAll from "../components/TitleForAll";
import { getContacts } from "@/lib/data/public-data";

export default async function ContactPage() {
  const contacts = await getContacts();

  return (
    <main className="flex flex-col lg:px-5 lg:pt-3 xl:px-16 xl:pt-6 gap-10 items-center justify-center">
      <TitleForAll
        titleThisPage="راه های ارتباطی من"
        textDetails="راه‌های ارتباطی من"
      />

      <ContactGrid
        contacts={contacts.map((contact) => ({
          ...contact,
          isActive: contact.is_active,
          sortOrder: contact.sort_order,
        }))}
      />

      <div className="mt-8 rounded-2xl border border-border bg-card px-4 py-5 sm:mt-10 sm:px-6">
        <p className="text-sm leading-7 text-muted-foreground">
          ممنون که برای ارتباط با من وقت گذاشتی.
          <span className="ms-1 font-semibold text-primary">
            منتظر پیامت هستم!
          </span>
        </p>
      </div>
    </main>
  );
}
